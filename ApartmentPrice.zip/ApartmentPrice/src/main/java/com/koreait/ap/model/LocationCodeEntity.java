package com.koreait.ap.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationCodeEntity {
    private int icd;
    private String localnm;
    private String excd;
}
